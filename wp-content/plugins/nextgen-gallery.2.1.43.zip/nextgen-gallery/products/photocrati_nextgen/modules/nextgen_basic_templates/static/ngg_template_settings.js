jQuery(function($){
    $('.ngg_settings_template').select2({
        placeholder: ngg_template_settings.placeholder_text,
        allowClear: true,
        width: 350
    });
});